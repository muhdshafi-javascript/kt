console.log('%c Async ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};
//#########################################################################
var employees = {
    msi11: {
        firstName: 'Muhammed',
        lastName: 'Shafi',
        yearOfJoining: 2012,
        skills: ['Java', 'JavaScript', 'RESTful Web Services'],
        designation: 'Manager'
    },

    mrr7: {
        firstName: 'Mounesh',
        lastName: 'Acharya',
        yearOfJoining: 2016,
        skills: ['Java', 'Angular', 'React'],
        designation: 'Developer'
    },

    so3: {
        firstName: 'Sandip',
        lastName: 'Sahoo',
        yearOfJoining: '01-01-2006',
        skills: ['Java', 'DBMS', 'Spring'],
        designation: 'Senior Manager'
    },

    rhr3: {
        firstName: 'Rakshitha',
        yearOfJoining: '01-012013',
        skills: ['Java', 'Spring'],
        designation: 'Senior Manager'
    },

    wgi: {
        firstName: 'Chakra',
        yearOfJoining: 2000,
        skills: ['Java', 'Spring', 'DBMS'],
        designation: 'Architect'
    },

    oyn: {
        lastName: 'Raj',
        yearOfJoining: '2005',
        skills: ['Java', 'Spring', 'MongoDB'],
        designation: 'Senior Manager'
    },
}



function getEmployeeDetails(id, callback) {
    setTimeout(function () {
        if (!employees[id]) {
            callback(new Error('Emplyee id not found!'));
            return;
        }
        callback(null, employees[id]);
    }, 500);
}


function getFullName(firstName, lastName, callback) {
    setTimeout(function () {
        if (!firstName || !lastName) {
            callback(new Error('Both First name and Last name are Mandatory!'));
            return;
        }
        callback(null, firstName + ' ' + lastName);
    }, 500);
}

function getYearsOfExperience(yearOfJoining, callback) {
    setTimeout(function () {
        if (!yearOfJoining || isNaN(yearOfJoining)) {
            callback(new Error('Invalid Year of joining'));
            return;
        }
        var currentYear = new Date().getFullYear();
        callback(null, currentYear - yearOfJoining);
    }, 500);
}


//#########################################################################
//Produce

//### 1 Promise creation
// var promise = new Promise(function(resolve, reject){
//     //executor body
//     //resolve();
//     //reject();
// });


//### 2 Promise resolve
// var promise = new Promise(function(resolve, reject){
//   resolve('Success');
//   reject('Failed');
// });

//Consume

//### then
//# resolve
// var promise = new Promise(function (resolve, reject) {
//     setTimeout(() => resolve("done!"), 1000);
// });
// promise.then(
//     result => myConsole.log(result),
//     error => myConsole.error(error)
// );

//# reject
// var promise = new Promise(function (resolve, reject) {
//     setTimeout(() => reject("failed!"), 1000);
// });
// promise.then(
//     result => myConsole.log(result),
//     error => myConsole.error(error)
// );

//# only resolve
// var promise = new Promise(function (resolve, reject) {
//     setTimeout(() => reject("Test Error"), 1000);
// });
// promise.then(result => myConsole.log(result));


//### catch
// var promise = new Promise(function (resolve, reject) {
//     reject("Test Error");
//     //throw new Error('eror');
// });
// promise.then(function(result){myConsole.info(result)}, error=>myConsole.error(error))
//         .catch(error => myConsole.log(error));

//### finally
//doesn't take any value




//##### Promise Chain 1

// var promise = new Promise((resolve, reject) => resolve(1));
// promise.then(result => result+1)
//        .then(result => myConsole.info(result));
//a call to promise.then returns a promise, so that we can call the next .then on it.


//##### Promise Chain 2
//return promise

//#### previous exmple



function getEmployeeDetails(id, callback) {
    setTimeout(function () {
        if (!employees[id]) {
            callback(new Error('Emplyee id not found!'));
            return;
        }
        callback(null, employees[id]);
    }, 500);
}

function getEmployeeDetailsPromise(id) {

    return new Promise(function(reolve, reject){
        setTimeout(function () {
            if (!employees[id]) {
                reject(new Error('Emplyee id not found!'));
            }
            reolve(employees[id]);
        }, 500);
    });
}


function getFullName(firstName, lastName, callback) {
    setTimeout(function () {
        if (!firstName || !lastName) {
            callback(new Error('Both First name and Last name are Mandatory!'));
            return;
        }
        callback(null, firstName + ' ' + lastName);
    }, 500);
}

function getFullNamePromise(firstName, lastName) {
    return new Promise(function(resolve, reject){
        setTimeout(function () {
            if (!firstName || !lastName) {
                reject(new Error('Both First name and Last name are Mandatory!'));
            }
            resolve(firstName + ' ' + lastName);
        }, 500);
    });
}

function getYearsOfExperience(yearOfJoining, callback) {
    setTimeout(function () {
        if (!yearOfJoining || isNaN(yearOfJoining)) {
            callback(new Error('Invalid Year of joining'));
            return;
        }
        var currentYear = new Date().getFullYear();
        callback(null, currentYear - yearOfJoining);
    }, 500);
}

function getYearsOfExperiencePromise(yearOfJoining) {
    return new Promise(function(resolve, reject){
        setTimeout(function () {
            if (!yearOfJoining || isNaN(yearOfJoining)) {
                reject(new Error('Invalid Year of joining'));
            }
            var currentYear = new Date().getFullYear();
            resolve(currentYear - yearOfJoining);
        }, 500);
    });
}



// function test(id){
//     var employee = {};
//     getEmployeeDetailsPromise(id).then(function(emp){
//         console.log(emp);
//         Object.assign(employee, emp);
//         return getFullNamePromise(employee.firstName, employee.lastName);
//     }).then(function(fullName){
//         myConsole.log(fullName);
//         employee.fullName = fullName;
//         return getYearsOfExperiencePromise(employee.yearOfJoining);
//     }).then(function(noOfYearsOfExp){
//         myConsole.log(noOfYearsOfExp);
//         employee.noOfYearsOfExp = noOfYearsOfExp;
//         console.log(employee);
//     });
// }

// function test(id){
//     var employee = {};
//     getEmployeeDetailsPromise(id).then(function(emp){
//         console.log(emp);
//         Object.assign(employee, emp);
//         return getFullNamePromise(employee.firstName, employee.lastName);
//     }).then(function(fullName){
//         myConsole.log(fullName);
//         employee.fullName = fullName;
//         return getYearsOfExperiencePromise(employee.yearOfJoining);
//     }).then(function(noOfYearsOfExp){
//         myConsole.log(noOfYearsOfExp);
//         employee.noOfYearsOfExp = noOfYearsOfExp;
//         console.log(employee);
//     }).catch(function(error){
//         myConsole.error(error);
//     });
// }



function test(id){
    var employee = {};
    getEmployeeDetailsPromise(id).then(function(emp){
        console.log(emp);
        Object.assign(employee, emp);
        return getFullNamePromise(employee.firstName, employee.lastName);
    }).then(function(fullName){
        myConsole.log(fullName);
        employee.fullName = fullName;
        return getYearsOfExperiencePromise(employee.yearOfJoining);
    }, function(error){
        myConsole.info(error);
        fullName = employee.firstName ? employee.firstName : employee.lastName;
        myConsole.log(fullName);
        employee.fullName = fullName;
        return getYearsOfExperiencePromise(employee.yearOfJoining);
    }).then(function(noOfYearsOfExp){
        myConsole.log(noOfYearsOfExp);
        employee.noOfYearsOfExp = noOfYearsOfExp;
        console.log(employee);
    }).catch(function(error){
        myConsole.error(error);
    });
}


// function test(id){
//     var employee = {};
//     getEmployeeDetailsPromise(id).then(function(emp){
//         console.log(emp);
//         Object.assign(employee, emp);
//         return getFullNamePromise(employee.firstName, employee.lastName);
//     },function(error){
//         return new Promise(function(resolve, reject){
//             reject(error);
//         });
//     }).then(function(fullName){
//         myConsole.log(fullName);
//         employee.fullName = fullName;
//         return getYearsOfExperiencePromise(employee.yearOfJoining);
//     }).then(function(noOfYearsOfExp){
//         myConsole.log(noOfYearsOfExp);
//         employee.noOfYearsOfExp = noOfYearsOfExp;
//         console.log(employee);
//     }).catch(function(error){
//         myConsole.error(error);
//     });
// }