'use strict';
console.log('%c ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};

//################################## De-Structuring ###################################

//******** Array ***********
//Step 1
let employee = ['Shafi', 'Bangalore', 7, 'Java'];
const [name, lokation, experience, skill] = employee;

//Step 2
let employee = ['Shafi', 'Bangalore', 7, 'Core Java', 'Java EE', 'JavaScript', 'JAX-RS', 'Spring'];
const [name, lokation, experience, ...skill] = employee;


//Step 3
let employee = ['Shafi', 'Bangalore', 7, 'Core Java', 'Java EE', 'JavaScript', 'JAX-RS', 'Spring'];
let name, lokation, experience, skill;
[name, lokation, experience, ...skill] = employee;


//Step 4  ** Default values **
let employee = ['Shafi', 'Bangalore', 7, ['Angular', 'Spring' ]];
let name, lokation, experience, skill;
[name, lokation, experience, skill = ['Java', 'JavaScript']] = employee;

//***** swap values ******
let a = 'Shafi';
let b = 'Muhammed';
console.log(a, b);
[a, b] = [b, a];
console.log(a, b);

// return multiple value as Array from fn
function getEmpDetails(){
    return ['Shafi', 'Bangalore', ['Java', 'JavaScript']];
}
const [name, lokation, skills] = getEmpDetails();

// ignore values
function getEmpDetails(){
    return ['Shafi', 'Bangalore', ['Java', 'JavaScript']];
}
const [name,, skills] = getEmpDetails();

//******************  Object  ********************
//Step1 - basic, differe name, default value
let employee = {
    name: 'Shafi',
    //location: 'Bangalore',
    skills: ['Java', 'JavaScript', 'JAX-RS']
}

var { name, skills, location:lokation = 'Kerala' } = employee;


//As Parameter of a funtion
let employee = {
    displayName : 'Shafi',
    fullName: {
        firstName: 'Muhammed',
        lastName: 'Shafi'
    },
    skills: ['Java', 'JavaScript'],
    experience:7
}

function getFullName({fullName: { firstName, lastName }} ) {
    return `${firstName} ${lastName}`;
}

function getTitle({displayName}){
    return `display name is ${displayName}`;
}

function getEmployeeExperience({experience = 0, displayName}){
    return `${displayName} has ${experience} years of experience`;
}

//Nested Object
let employee = {
    displayName: 'Shafi',
    fullName: {
        firstName: 'Muhammed',
        lastName: 'Shafi'
    },
    skills: ['Java', 'JavaScript'],
    experience: 7
}

let fullName, firstName, lastName, displayName;
({ fullName: { firstName, lastName }, displayName } = employee);


//Handle errors with fn paramerters
function printEmpDetails({name = 'Dummy Name', exp = 0, skill = 'Web Development'} /*= {}*/) {
    console.log(`${name} has ${exp} years of experience in ${skill}`);    
}
printEmpDetails({
    name: 'Shafi',
    exp:7,
    skill:'Full Stack Development'
});

printEmpDetails({
    name: 'Shafi',
    skill:'Full Stack Development'
});

printEmpDetails({
    name: 'Shafi'
});

printEmpDetails({});

printEmpDetails();

