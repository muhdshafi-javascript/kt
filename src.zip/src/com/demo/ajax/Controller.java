package com.demo.ajax;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Path("services")
public class Controller {

	@Path("employees")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response listEmployees() {
		return Response.ok(Data.getInstance().listEmplyees()).build();
	}

	@Path("employees")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createEmployee(Employee emp) {
		try {
			return Response.ok(Data.getInstance().addEmpoyee(emp)).build();
		} catch (Exception e) {
			return Response.status(Status.CONFLICT).build();
		}
	}

	@Path("employees/{id}")
	@GET
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Response getEmployeeInfo(@PathParam("id") String id) {
		try {
			return Response.ok(Data.getInstance().getEnployeeInfo(id)).build();
		} catch (Exception e) {
			return Response.status(Status.NOT_FOUND).build();
		}

	}

	@Path("employees/{id}")
	@DELETE
	public Response deleteEmployee(@PathParam("id") String id) {
		if (Data.getInstance().deleteEnployee(id)) {
			return Response.noContent().build();
		}
		return Response.status(Status.NOT_FOUND).build();
	}

}
