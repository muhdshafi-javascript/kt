'use strict';
console.log('%c ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};

//################################## De-Structuring ###################################
// var emp = {
//     firstName: 'Muhammed',
//     lastName: 'Shafi',
//     location: 'Bangalore',
//     yoj: 2012,
//     yearsOfExp: function(){
//         return (new Date().getFullYear() - this.yoj);
//     }
// }


var person = {
    firstName: "John",
    lastName: "Doe",
    language: "en",
    get lang() {
        return this.language;
    },
    set lang(lang) {
        this.language = lang;
    },
    get fullName() {
        return this.firstName + ' ' + this.lastName;
    }
};


function details() {
    var name;
    var age;

    for (var i = 0; i < arguments.length; i++) {
        var arc = arguments[i];
        if (typeof arg[0] !== "string") throw " invalid first argument ";

        if (typeof arg[1] !== " number") throw "invalid second argument";
    };

    return {
        get: function () { return this.name + " is " + this.age; },
        set: function (name, age) {
            this.name = name;
            this.age = age;

        }

    }

}
