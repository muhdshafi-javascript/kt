'use strict';
console.log('%c ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};

//################################## De-Structuring ###################################

//Array
//  var person = ['Shafi', 'Software Developer'];
// //ES 5
// var name = person[0];
// var job = person[1];
// console.log(name + ' is a ' + job);

// //ES 6
// const [name, job] = person;
// console.log(`${name} is a ${job}`);

//Object  - same as key
var person = {
    name: 'Shafi',
    job:'Software Developer'    
}
// //ES 5
// var name = person.name;
// var job = person.job;
// console.log(name + ' is a ' + job);

//ES 6 
// const {name, job} = person;
// console.log(`${name} is a ${job}`);

// const{name:title, job:role} = person;
// console.log(`${title} is a ${role}`);
