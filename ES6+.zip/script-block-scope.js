'use strict';
console.log('%c ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};


//################################## var, let and const ###################################
//******* VAR ****** 
//step 1 
// var age = 31;
// var age = 32;
// myConsole.log(age);

//Step 2
// var age = 31;
// if(true){
//     var age = 32;
// }
// myConsole.log(age);

//Step 3
// var age = 31;
// function test(){
//     var age = 32;
//     myConsole.info(age);
// }
// test();
// myConsole.log(age);

//Step 4 IIFE
// var age = 31;
// var newAge = (function(){
//     var age = 32;
//     return age;
// }());
// myConsole.log(age);
// myConsole.log(newAge);

//************ LET ************* 
//Step 1
// let age = 31;
// //let age = 34;
// {
//     let age = 32;
//     myConsole.log(++age);
// }
// myConsole.info(age);

//Step 2 Hoisting with LET and CONST
// myConsole.error(age);
// var age;
// myConsole.error(address);
// let address;
// myConsole.error(street);

//************ CONST ************* 
//Step 1
// const yob; /*= 1988 ;*/
// //yob++;
// myConsole.log(yob);

//Step 2 Hoisting
// myConsole.error(address);
// const address = 'BN'

//VAR and LET together
// let age = 31;{
//     var age = 32;
// }
// myConsole.log(age);





