console.log('Hello World');

//xhr.setRequestHeader('Accept', 'application/xml');
//xhr.setRequestHeader('Authorization', 'Basic YWJjZDoxMjM0');

function listEmp(callback) {
    console.log('list');

    var xhr = new XMLHttpRequest();
    xhr.open('GET',
        'http://localhost:8080/AJAX_Demo/services/employees');

    xhr.onreadystatechange = function AjaxCallBack() {
        if (this.readyState === 4) {
            // console.log(this.status);
            // console.log(this.statusText);
            // console.log(this.responseText);
            //console.log(this.responseXML);

            if(typeof callback === 'function'){
                callback(this);
            }
        }
    }
    xhr.send();

}

function addEmp(data) {
    console.log('add');

    var xhr = new XMLHttpRequest();
    xhr.open('POST',
        'http://localhost:8080/AJAX_Demo/services/employees');

   xhr.setRequestHeader('Accept', 'application/json');
   xhr.setRequestHeader('Content-Type', 'application/json');

    xhr.onreadystatechange = function AjaxCallBack() {
        if (this.readyState === 4) {
            // console.log(this.status);
            // console.log(this.statusText);
            // console.log(this.responseText);
            //console.log(this.responseXML);

        }
    }
    xhr.send(JSON.stringify(data));


}

function viewEmp(id) {

    var xhr = new XMLHttpRequest();
    xhr.open('GET',
        'http://localhost:8080/AJAX_Demo/services/employees/' + id);

    xhr.onreadystatechange = function AjaxCallBack() {
        if (this.readyState === 4) {
            console.log(this.status);
            console.log(this.responseText);
            console.log(this.responseXML);
        }
    }
    xhr.send();

    console.log('view');
}

function deleteEmp(id) {
    console.log('delete');

    var xhr = new XMLHttpRequest();
    xhr.open('DELETE',
        'http://localhost:8080/AJAX_Demo/services/employees/' + id);

    xhr.onreadystatechange = function AjaxCallBack() {
        if (this.readyState === 4) {
            console.log(this.status);
        }
    }
    xhr.send();
}

// addEmp({
//     "name": "Mounesh",
//     "role": "Developer",
//     "team": "EM",
//     "triagram": "mns",
//     "yearsOfExperience": 7
// });



// listEmp(function(data){
//     var jsonRes = JSON.parse(data.responseText);
//     if( jsonRes.length != 0){
//         viewEmp(jsonRes[0]);
//     }
// });

responseContext.getHeaders().add("Access-Control-Allow-Headers", "Authorization");
responseContext.getHeaders().add("Access-Control-Allow-Headers", "Content-Type");
responseContext.getHeaders().add("Access-Control-Allow-Headers", "Content-Type");
responseContext.getHeaders().add("Access-Control-Allow-Methods", "DELETE");