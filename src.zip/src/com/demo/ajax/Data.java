package com.demo.ajax;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Data {

	private static List<Employee> list = new ArrayList<>();

	private Data() {
		Employee emp = new Employee();
		emp.setTriagram("msi11");
		emp.setName("Shafi");
		emp.setTeam("EM");
		emp.setRole("Developer");
		emp.setYearsOfExperience(7);
		list.add(emp);

		emp = new Employee();
		emp.setTriagram("so3");
		emp.setName("Sandip");
		emp.setTeam("EM");
		emp.setRole("Manager");
		emp.setYearsOfExperience(13);
		list.add(emp);
	}

	private static Data instance = new Data();

	public static Data getInstance() {
		return instance;

	}

	public List<String> listEmplyees() {
		return list.stream().map(emp -> emp.getTriagram()).collect(Collectors.toList());
	}

	public Employee addEmpoyee(Employee emp) {

		if (emp.getTriagram() == null || emp.getTriagram().isEmpty()) {
			throw new RuntimeException("Triagram Missing");
		}

		if (list.stream().filter(current -> current.getTriagram().equalsIgnoreCase(emp.getTriagram()))
				.collect(Collectors.toList()).size() != 0) {
			throw new RuntimeException("Triagram Already Exists");
		}

		list.add(emp);
		return emp;
	}
	
	
	public Employee getEnployeeInfo(String id) {
		List<Employee> filteredList = list.stream().filter(current -> current.getTriagram().equalsIgnoreCase(id))
				.collect(Collectors.toList());
		if (filteredList.size() == 0) {
			throw new RuntimeException("Triagram Doesn't Exists");
		}
		
		return filteredList.get(0);
	}

	public boolean deleteEnployee(String id) {
		List<Employee> filteredList = list.stream().filter(current -> current.getTriagram().equalsIgnoreCase(id))
				.collect(Collectors.toList());
		if (filteredList.size() == 0) {
			throw new RuntimeException("Triagram Doesn't Exists");
		}
		
		return list.remove(filteredList.get(0));
	}
	
}
