'use strict';
console.log('%c ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};

//################################## Template Literals ###################################
//step 1
let comment = 'Shafi\n' +
    'Software Developer\n' +
    'Banglore';
console.log(comment);

let comment2 = `Shafi
Software Developer
Banglore`;
console.log(comment2);
//Step 2
let name = 'Shafi';
let job = 'Software Developer';
myConsole.error(name + ' is a ' + job);
myConsole.log(`${name} is a ${job}`);






