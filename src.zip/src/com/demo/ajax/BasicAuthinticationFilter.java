package com.demo.ajax;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

@Provider
public class BasicAuthinticationFilter implements ContainerRequestFilter {

	@Override
	public void filter(ContainerRequestContext ctx) throws IOException {
		String auth = ctx.getHeaderString("Authorization");
		if (auth == null || auth.isEmpty() || !auth.equals("Basic YWJjZDoxMjM0")) {//abcd/1234
			ctx.abortWith(Response.status(Response.Status.UNAUTHORIZED).entity("Cannot access").build());
		}
	}

}
