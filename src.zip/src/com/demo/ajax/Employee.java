package com.demo.ajax;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Employee {
	private String triagram;
	private String name;
	private String team;
	private int yearsOfExperience;
	private String role;

	public String getTriagram() {
		return triagram;
	}

	public void setTriagram(String triagram) {
		this.triagram = triagram;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public int getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
