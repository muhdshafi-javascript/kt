'use strict';
console.log('%c ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};

//################################## Class ###################################
//ES 5
var Person = function (name, yob) {
    this.name = name;
    this.yob = yob;
}
Person.prototype.getAge = function () {
    console.log(new Date().getFullYear() - this.yob);
}
Person.sayHello = function () {
    console.log('Hello..., have a nice day, greetings from the Static method');
}

var Student = function (name, yob, dep) {
    Person.call(this, name, yob);
    this.dep = dep;
}
Student.prototype = Object.create(Person.prototype);
Object.defineProperty(Student.prototype, 'constructor', {
    value: Student,
    configurable: false,
    enumerable: false,
    writable: false
});
Student.prototype.getDep = function () {
    console.log(this.name + ' belongs to ' + this.dep);
}
//Object.assign(Student, Person);
// Object.keys(Person).forEach(function(key){
//     if(typeof Person[key] === 'function'){
//         Student[key] = Person[key];
//     }
// });

Student.__Proto__ = Person;

var shafi = new Person('Shafi', 1988);
var mounesh = new Student('Mounesh', 1993, 'CSE');


//ES 6

class Person6 {
    constructor(name, yob) {
        this.name = name;
        this.yob = yob;
    }
    getAge() {
        console.log(new Date().getFullYear() - this.yob);
    }

    static sayHello() {
        console.log('Hello..., have a nice day, greetings from the Static method');
    }
}

class Student6 extends Person6 {
    constructor(name, yob, dep) {
        super(name, yob);
        this.dep = dep;
    }
    getDep() {
        console.log(`${this.name} belongs to ${this.dep}`);
    }
}


let sanjay = new Person6('Sanjay', 1990);
let rakshitha = new Student6('Rakshitha', 1990, 'CSE');
