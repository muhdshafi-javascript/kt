//'use strict';
console.log('%c ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};

//############################# Symbols ########################################

// const symbol1 = Symbol();
// const symbol2 = Symbol('name');

// const person = {
//     name: 'Shafi'
// };
// const name = Symbol('name');
// person[name] = 'Sandip';
// console.log(person[name]);

//############################# Iterator ########################################

// //Simple Iterator Impl
// //next method and result with value and done
// function getIterator(start = 0, end = 100, step = 1) {
//     let next = start;
//     return {
//         next: function () {
//             if (next <= end) {
//                 let result = { value: next, done: false };
//                 next += step;
//                 return result;
//             } else {
//                 return { value: undefined, done: true }
//             }
//         }
//     };
// }

// let itr = getIterator(0, 10, 3);
// let result = itr.next();
// while(!result.done){
//     console.log(result.value);
//     result = itr.next();
// }



let testOld = {
    [Symbol.iterator]: function (start = 0, end = 20, step = 1) {
        let nextIndex = start;
        let iterationCount = 0;

        const rangeIterator = {
            next: function () {
                let result;
                if (nextIndex < end) {
                    result = { value: nextIndex, done: false }
                    nextIndex += step;
                    iterationCount++;
                    return result;
                }
                return { value: iterationCount, done: true }
            }
        };
        return rangeIterator;
    }
}

let test = {
    [Symbol.iterator]: function* (start = 0, end = 20, step = 1) {
        for (let i = start; i < end; i++) {
            yield i;
        }
    }
}

for (let val of test[Symbol.iterator]()) {
    console.log(val);
}

console.log(...test[Symbol.iterator]());

let x = Array.from(test);

for (let val of x.entries()) {
    console.log(val);
}

let itr = test[Symbol.iterator]();


for (let val of itr) {
    console.log(val);
}
