console.log('%c Async ES6+ ', 'background: black; color: yellow; padding-left:300px; padding-right:300px;padding-top:5px; padding-bottom:5px;');

var myConsole = {
    error: function myConsole(message) {
        console.log('%c ' + message, 'background: #B30526; color: white;padding-left:20px; padding-right:20px;');
    },
    info: function myConsole(message) {
        console.log('%c ' + message, 'background: #AFE4F1; color: black;padding-left:20px; padding-right:20px;');
    },
    log: function myConsole(message) {
        console.log('%c ' + message, 'background: #0D45EC; color: white; padding-left:20px; padding-right:20px;');
    }
};



//0. Error Handling
//a) synchronous
//b) asynchronous
//1. Callback Hell
//2. Promises
//3. Arrow Functions
//4. Async/Await

//###############################################################################################
//Synchronous Error Handling
// function getFullNameSync(firstName, lastName) {
//     if (!firstName || !lastName) {
//         throw new Error('Either First Name or Last Name or both are invalid!!!');
//     }
//     return firstName + ' ' + lastName;
// }

// function testGetFullNameSync(firstName, lastName) {
//     var fullname = getFullNameSync(firstName, lastName);
//     console.log('Got the result');
//     console.log(fullname);
// }

//Error Handling

// function testGetFullNameSync(firstName, lastName){
//     try {
//         var fullname = getFullNameSync(firstName, lastName);
//         console.log('Got the result');
//         console.log(fullname);
//     } catch (error) {
//         myConsole.error(error.message);
//     }
// }



//Asynchronous Error Handling

// function getFullNameAsync(firstName, lastName, callback){
//     setTimeout(function(){
//         if(!firstName || !lastName){
//             throw new Error('Either First Name or Last Name or both are invalid!!!');
//         }
//         callback(firstName + ' ' + lastName);
//     }, 500);
// }

// function testGetFullNameAsync(firstName, lastName){
//     getFullNameAsync(firstName, lastName, function(fullname){
//         console.log('Got the result');
//         console.log(fullname);
//     });
//     console.log('End of testGetFullNameAsync');
// }

//Handle error

// function testGetFullNameAsync(firstName, lastName){
//     try {
//         getFullNameAsync(firstName, lastName, function(fullname){
//             console.log('Got the result');
//             console.log(fullname);
//         });
//         console.log('End of testGetFullNameAsync');
//     } catch (error) {
//         myConsole.error(error.message);
//     }

// }



//Solution 1 - Use seperate Callbacks for error and successs

// function getFullNameAsync(firstName, lastName, successsCallback, errorCallback){
//     setTimeout(function(){
//         if(!firstName || !lastName){
//             //throw new Error('Either First Name or Last Name or both are invalid!!!');
//             errorCallback(new Error('Either First Name or Last Name or both are invalid!!!'));
//             return;
//         }
//         successsCallback(firstName + ' ' + lastName);
//     }, 500);
// }

// function testGetFullNameAsync(firstName, lastName){
//     getFullNameAsync(firstName, lastName, function(fullname){
//         console.log('Got the result');
//         console.log(fullname);
//     }, function(error){
//         myConsole.error(error.message);
//     });
//     console.log('End of testGetFullNameAsync');
// }





//Solution 2 - Use an additional argument for error same callback

// function getFullNameAsync(firstName, lastName, callback) {
//     setTimeout(function () {
//         if (!firstName || !lastName) {
//             //throw new Error('Either First Name or Last Name or both are invalid!!!');
//             callback(new Error('Either First Name or Last Name or both are invalid!!!'));
//             return;
//         }
//         callback(null, firstName + ' ' + lastName);
//     }, 500);
// }

// function testGetFullNameAsync(firstName, lastName) {
//     getFullNameAsync(firstName, lastName, function (error, fullname) {
//         if (error) {
//             myConsole.error(error.message);
//             return;
//         }
//         console.log('Got the result');
//         console.log(fullname);

//     });
//     console.log('End of testGetFullNameAsync');
// }


//###############################################################################################




var employees = {
    msi11: {
        firstName: 'Muhammed',
        lastName: 'Shafi',
        yearOfJoining: 2012,
        skills: ['Java', 'JavaScript', 'RESTful Web Services'],
        designation: 'Manager'
    },

    mrr7: {
        firstName: 'Mounesh',
        lastName: 'Acharya',
        yearOfJoining: 2016,
        skills: ['Java', 'Angular', 'React'],
        designation: 'Developer'
    },

    so3: {
        firstName: 'Sandip',
        lastName: 'Sahoo',
        yearOfJoining: '01-01-2006',
        skills: ['Java', 'DBMS', 'Spring'],
        designation: 'Senior Manager'
    },

    rhr3: {
        firstName: 'Rakshitha',
        yearOfJoining: '01-012013',
        skills: ['Java', 'Spring'],
        designation: 'Senior Manager'
    },

    wgi: {
        firstName: 'Chakra',
        yearOfJoining: 2000,
        skills: ['Java', 'Spring', 'DBMS'],
        designation: 'Architect'
    },

    oyn: {
        lastName: 'Raj',
        yearOfJoining: '2005',
        skills: ['Java', 'Spring', 'MongoDB'],
        designation: 'Senior Manager'
    },
}



function getEmployeeDetails(id, callback) {
    setTimeout(function () {
        if (!employees[id]) {
            callback(new Error('Emplyee id not found!'));
            return;
        }
        callback(null, employees[id]);
    }, 500);
}


function getFullName(firstName, lastName, callback) {
    setTimeout(function () {
        if (!firstName || !lastName) {
            callback(new Error('Both First name and Last name are Mandatory!'));
            return;
        }
        callback(null, firstName + ' ' + lastName);
    }, 500);
}

function getYearsOfExperience(yearOfJoining, callback) {
    setTimeout(function () {
        if (!yearOfJoining || isNaN(yearOfJoining)) {
            callback(new Error('Invalid Year of joining'));
            return;
        }
        var currentYear = new Date().getFullYear();
        callback(null, currentYear - yearOfJoining);
    }, 500);
}




//Test get Details
function testGetDetails(id) {
    getEmployeeDetails(id, function (error, employee) {
        if (error) {
            myConsole.error(error.message);
            return;
        }
        console.log(employee);
    });
}

//Test get full name
function testFullName(firstName, lastName) {
    getFullName(firstName, lastName, function (error, fullName) {
        if (error) {
            myConsole.error(error.message);
            return;
        }
        console.log(fullName);
    });
}

//Test get year of experience
function testYearOfExperience(yearOfJoining) {
    getYearsOfExperience(yearOfJoining, function (error, yearsOfExperience) {
        if (error) {
            myConsole.error(error.message);
            return;
        }
        console.log(yearsOfExperience);
    });
}



// function test(id) {

//     getEmployeeDetails(id, function (error, emp) {
//         console.log(emp);

//         getFullName(emp.firstName, emp.lastName, function (error, fullName) {
//             myConsole.info(fullName);

//             var employee = Object.assign({}, emp);
//             employee.fullName = fullName;
//             getYearsOfExperience(employee.yearOfJoining, function (error, yearsOfExperience) {
//                 myConsole.info(yearsOfExperience);

//                 employee.yearsOfExperience = yearsOfExperience;
//                 setTimeout(function () {
//                     console.log(employee);
//                 }, 500);
//             });
//         });
//     });
// }

//Handle Errors from callbacks
// function test(id) {

//     getEmployeeDetails(id, function (error, emp) {
//         if(error){
//             myConsole.error(error.message);
//             return;
//         }
//         console.log(emp);

//         getFullName(emp.firstName, emp.lastName, function (error, fullName) {
//             if(error){
//                 myConsole.info(error.message);
//                 //Handle error in fullname
//                 fullName = emp.firstName ? emp.firstName : emp.lastName;
//             }
//             myConsole.log(fullName);

//             var employee = Object.assign({}, emp);
//             employee.fullName = fullName;
//             getYearsOfExperience(employee.yearOfJoining, function (error, yearsOfExperience) {
//                 if(error){
//                     myConsole.info(error.message);
//                     //Handle error in years of exp
//                     yearsOfExperience = 0;
//                 }
//                 myConsole.log(yearsOfExperience);

//                 employee.yearsOfExperience = yearsOfExperience;
//                 setTimeout(function () {
//                     console.log(employee);
//                 }, 500);
//             });
//         });
//     });
// }

//Handle Errors in client funtions
// function test(id) {
//     try {
//         //Simulate a runtime Error
//         //x.title = 'Wolverine';

//         getEmployeeDetails(id, function (error, emp) {

//             try {
//                 if (error) {
//                     myConsole.error(error.message);
//                     return;
//                 }
//                 console.log(emp);
//                 //Simulate a runtime Error
//                 y.title = 'Wolverine';

//                 getFullName(emp.firstName, emp.lastName, function (error, fullName) {
//                     if (error) {
//                         myConsole.info(error.message);
//                         //Handle error in fullname
//                         fullName = emp.firstName ? emp.firstName : emp.lastName;
//                     }
//                     myConsole.log(fullName);

//                     var employee = Object.assign({}, emp);
//                     employee.fullName = fullName;
//                     getYearsOfExperience(employee.yearOfJoining, function (error, yearsOfExperience) {
//                         if (error) {
//                             myConsole.info(error.message);
//                             //Handle error in years of exp
//                             yearsOfExperience = 0;
//                         }
//                         myConsole.log(yearsOfExperience);

//                         employee.yearsOfExperience = yearsOfExperience;
//                         setTimeout(function () {
//                             console.log(employee);
//                         }, 500);
//                     });
//                 });
//             } catch (error) {
//                 myConsole.info(error.message);
//                 getFullName(emp.firstName, emp.lastName, function (error, fullName) {
//                     if (error) {
//                         myConsole.info(error.message);
//                         //Handle error in fullname
//                         fullName = emp.firstName ? emp.firstName : emp.lastName;
//                     }
//                     myConsole.log(fullName);

//                     var employee = Object.assign({}, emp);
//                     employee.fullName = fullName;
//                     getYearsOfExperience(employee.yearOfJoining, function (error, yearsOfExperience) {
//                         if (error) {
//                             myConsole.info(error.message);
//                             //Handle error in years of exp
//                             yearsOfExperience = 0;
//                         }
//                         myConsole.log(yearsOfExperience);

//                         employee.yearsOfExperience = yearsOfExperience;
//                         setTimeout(function () {
//                             console.log(employee);
//                         }, 500);
//                     });
//                 });
//             }


//         });
//     } catch (error) {
//         myConsole.error(error.message);
//     }
// }



//Handle Errors in client funtions - reusable fns
function test(id) {
    try {
        //Simulate a runtime Error
        //x.title = 'Wolverine';
        getEmployeeDetails(id, function (error, emp) {
            try {
                if (error) {
                    myConsole.error(error.message);
                    return;
                }
                console.log(emp);
                //Simulate a runtime Error
                y.title = 'Wolverine';
                fnA(emp);

            } catch (error) {
                myConsole.info(error.message);
                fnA(emp);
            }
        });
    } catch (error) {
        myConsole.error(error.message);
    }
}

function fnA(emp) {
    getFullName(emp.firstName, emp.lastName, function (error, fullName) {
        if (error) {
            myConsole.info(error.message);
            //Handle error in fullname
            fullName = emp.firstName ? emp.firstName : emp.lastName;
        }
        myConsole.log(fullName);

        var employee = Object.assign({}, emp);
        employee.fullName = fullName;
        getYearsOfExperience(employee.yearOfJoining, function (error, yearsOfExperience) {
            if (error) {
                myConsole.info(error.message);
                //Handle error in years of exp
                yearsOfExperience = 0;
            }
            myConsole.log(yearsOfExperience);

            employee.yearsOfExperience = yearsOfExperience;
            setTimeout(function () {
                console.log(employee);
            }, 500);
        });
    });
}